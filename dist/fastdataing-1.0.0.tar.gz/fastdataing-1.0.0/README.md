### Common fast data processing methods

#### Smooth

- smooth_MIS(x,y,factor=300):
- smooth_SF(x,y,factors=[5,3]):