### Common fast data processing methods

#### Smooth

- smooth_MIS(x,y,factor=300): 
  - smooth data
- smooth_SF(x,y,factors=[5,3]): 
  - smooth data

### files processing

- get_files(directory, suffix): 
  - Read files with the same suffix in the folder and save them as a list